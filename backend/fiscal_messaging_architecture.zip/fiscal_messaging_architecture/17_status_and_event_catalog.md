# Status e Eventos

## Status de documento

Manter status de negócio separado do status técnico.

### `status`

- `received`
- `validating`
- `accepted_for_processing`
- `submitted`
- `authorized`
- `rejected`
- `cancel_requested`
- `cancelled`
- `denied`
- `completed`

### `processing_status`

- `pending`
- `queued`
- `processing`
- `waiting_external`
- `retry_scheduled`
- `failed`
- `dead_letter`
- `completed`

## Eventos

Usar passado para eventos ocorridos:

- `fiscal.document.received.v1`
- `fiscal.document.validated.v1`
- `fiscal.document.queued.v1`
- `fiscal.document.transmission_started.v1`
- `fiscal.document.submitted.v1`
- `fiscal.document.authorized.v1`
- `fiscal.document.rejected.v1`
- `fiscal.document.retry_scheduled.v1`
- `fiscal.document.failed.v1`
- `fiscal.document.cancelled.v1`

Comandos internos podem usar intenção:

- `fiscal.document.transmit.v1`
- `fiscal.document.requery.v1`
- `webhook.deliver.v1`

## Compatibilidade

Nunca alterar semanticamente um evento publicado. Criar `.v2` e manter consumidores durante migração.
