# Inbound API

## Endpoint conceitual

```http
POST /v1/fiscal_documents
Authorization: Bearer <access_token>
Idempotency-Key: <uuid>
X-Correlation-Id: <uuid opcional>
Content-Type: application/json
```

Resposta:

```json
{
  "document_id": "uuid",
  "trace_id": "uuid",
  "status": "received"
}
```

HTTP `202 Accepted`.

## Credenciais técnicas

Não usar conta humana do SAP.

Entidades:

- `organization_api_clients`
- `organization_api_client_credentials`
- `organization_api_client_scopes`
- `organization_api_client_ip_rules`

Usar OAuth 2.0 client credentials ou JWT client assertion. Para integrações críticas, considerar mTLS.

O token deve conter:

- `sub`
- `organization_id`
- `client_id`
- `scopes`
- `aud`
- `iss`
- `iat`
- `exp`
- `jti`

Nunca permitir que um client escolha outro tenant no body.

## Pipeline

1. WAF e limite de tamanho.
2. TLS.
3. validação do token.
4. rate limit por client/tenant.
5. resolução da empresa por identificador permitido.
6. validação do serviço ativo.
7. validação de Content-Type e schema.
8. idempotência.
9. persistência do payload no object storage.
10. gravação atômica de documento, evento, trace e outbox.
11. resposta 202.

## Proteções

- limite por payload e tipo;
- streaming para evitar uso excessivo de memória;
- proteção contra XML bombs e XXE;
- validação estrita de JSON/XML;
- timeout curto;
- sem chamadas à SEFAZ na request;
- resposta sem stack trace;
- quotas por organização;
- circuit breaker apenas para dependências inevitáveis.
