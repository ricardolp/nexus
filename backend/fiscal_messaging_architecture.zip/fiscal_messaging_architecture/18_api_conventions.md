# Convenções de API

## Paths

```text
/v1/organizations
/v1/organizations/{organization_id}/members
/v1/organizations/{organization_id}/roles
/v1/organizations/{organization_id}/companies
/v1/organizations/{organization_id}/integrations
/v1/organizations/{organization_id}/webhook_endpoints
/v1/fiscal_documents
/v1/fiscal_documents/{document_id}
/v1/fiscal_documents/{document_id}/timeline
```

Para usuários de tenant, preferir organização inferida da sessão quando possível, reduzindo risco de IDOR.

## Erros

Formato Problem Details:

```json
{
  "type": "https://errors.example.com/document_service_disabled",
  "title": "Service is not enabled",
  "status": 422,
  "code": "document_service_disabled",
  "detail": "The requested fiscal service is not enabled for this company.",
  "trace_id": "uuid"
}
```

## Paginação

Cursor-based:

- `limit`
- `after`
- `before`

## Concorrência

Usar ETag/`If-Match` ou campo `version` para alterações administrativas.

## Idempotência

Operações de criação e comandos fiscais aceitam `Idempotency-Key`. Armazenar:

- hash do request;
- status;
- response;
- expiração.

Reutilização da chave com payload diferente retorna conflito.

## Versionamento

Versionar APIs e payloads de evento. Depreciação deve possuir prazo e telemetria de uso.
