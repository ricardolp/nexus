# Documentos Fiscais

## Modelo

Usar uma entidade raiz genérica e extensões por domínio.

### `organization_documents`

Metadados comuns:

- `id`
- `organization_id`
- `organization_company_id`
- `document_type`
- `direction`
- `environment`
- `external_id`
- `source_system`
- `source_document_id`
- `idempotency_key`
- `document_key`
- `status`
- `processing_status`
- `current_version`
- `correlation_id`
- `trace_id`
- `received_at`
- `completed_at`
- `created_at`
- `updated_at`

`direction`:

- `inbound`
- `outbound`

`document_type`:

- `nfe`
- `nfse`
- futuramente `cte`, `mdfe`, etc.

### Extensões

- `organization_nfe`
- `organization_nfse`

Cada uma contém somente atributos específicos do tipo e FK 1:1 para `organization_documents`.

## Payloads

### `organization_document_payloads`

Cada envio/resposta/versionamento:

- `id`
- `organization_id`
- `organization_document_id`
- `payload_type`
- `content_type`
- `storage_object_key`
- `sha256`
- `size_bytes`
- `encryption_key_version`
- `contains_sensitive_data`
- `created_at`

Tipos:

- `original_request`
- `normalized_request`
- `provider_request`
- `provider_response`
- `sefaz_response`
- `webhook_request`
- `webhook_response`

Não guardar payload fiscal grande em colunas de log.

## Eventos e histórico

### `organization_document_events`

Timeline imutável:

- `id`
- `organization_id`
- `organization_document_id`
- `event_type`
- `from_status`
- `to_status`
- `actor_type`
- `actor_id`
- `correlation_id`
- `trace_id`
- `metadata_json`
- `occurred_at`

### `organization_document_attempts`

Uma tentativa de processamento externo:

- `attempt_number`
- `provider`
- `operation`
- `started_at`
- `finished_at`
- `outcome`
- `http_status`
- `error_code`
- `error_message_sanitized`
- `request_payload_id`
- `response_payload_id`

## Idempotência

Chave única recomendada:

```text
organization_id + organization_company_id + source_system + idempotency_key
```

Para documentos com chave fiscal conhecida, adicionar restrição de negócio coerente com ambiente, tipo e direção.
