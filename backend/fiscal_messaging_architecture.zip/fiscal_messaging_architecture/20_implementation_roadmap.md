# Roadmap de Implementação

## Fase 1 — Fundação

- convenções;
- PostgreSQL;
- migrations;
- organizations;
- users;
- memberships;
- roles;
- permissions;
- companies;
- serviços;
- auditoria básica;
- CI/CD;
- secrets manager.

## Fase 2 — Autenticação

- login;
- verificação de e-mail;
- convites;
- sessões;
- recuperação;
- TOTP;
- recovery codes;
- políticas por tenant;
- admin da plataforma;
- suporte auditado.

## Fase 3 — Inbound fiscal

- API clients;
- OAuth client credentials;
- inbound API;
- idempotência;
- object storage;
- documents;
- payloads;
- events;
- outbox.

## Fase 4 — Processamento

- broker;
- workers;
- inbox;
- retry;
- dead-letter;
- conector fiscal;
- normalização de status;
- reconciliação.

## Fase 5 — SAP e Webhooks

- organization integrations;
- secrets;
- custom headers seguros;
- callbacks;
- subscriptions;
- assinatura HMAC;
- retries;
- replay manual.

## Fase 6 — Operação e compliance

- OpenTelemetry;
- dashboards;
- alertas;
- SIEM;
- retenção;
- LGPD;
- DR;
- pentest;
- ASVS;
- SSO OIDC/SAML;
- WebAuthn.

## Critério de pronto

Uma funcionalidade só está pronta quando possui:

- autorização;
- validação;
- auditoria;
- observabilidade;
- testes unitários;
- testes de integração;
- testes de isolamento de tenant;
- migration;
- documentação;
- tratamento de idempotência/retry quando aplicável.
