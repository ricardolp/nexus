# Organizations, Companies e Serviços

## `organizations`

Tenant contratante.

Campos:

- `id`
- `legal_name`
- `trade_name`
- `slug`
- `tax_identifier`
- `status`
- `timezone`
- `default_locale`
- `data_region`
- `plan_id`
- `created_at`
- `updated_at`

## `organization_companies`

Empresas/CNPJs pertencentes ao tenant.

Campos:

- `id`
- `organization_id`
- `legal_name`
- `trade_name`
- `cnpj`
- `state_registration`
- `municipal_registration`
- `tax_regime`
- `environment`
- `timezone`
- `status`
- `metadata_json`

Unique: `(organization_id, cnpj)`.

## Catálogo de serviços

### `services`

Catálogo global controlado pelo SaaS.

Exemplos:

- `nfe_inbound`
- `nfe_outbound`
- `nfse_inbound`
- `nfse_outbound`
- `cte`
- `mdfe`
- `event_cancellation`
- `document_distribution`

### `organization_company_services`

Ativação por empresa.

Campos:

- `organization_id`
- `organization_company_id`
- `service_id`
- `status`
- `configuration_json`
- `activated_at`
- `deactivated_at`

Unique: `(organization_company_id, service_id)`.

A API deve recusar documento cujo serviço não esteja ativo para a empresa.

## Ambiente

A empresa pode possuir configurações distintas para:

- `production`
- `homologation`

Credenciais e endpoints nunca devem ser compartilhados entre ambientes.
